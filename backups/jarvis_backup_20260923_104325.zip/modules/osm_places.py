import csv
import os
from datetime import datetime
from pathlib import Path

import requests

# Overpass API endpoint
OVERPASS_URL = "https://overpass-api.de/api/interpreter"

def search_businesses_without_websites(query, area_name=None, timeout=60):
    """
    Search OpenStreetMap via Overpass API for businesses without websites.
    
    :param query: The type of business (e.g., 'restaurant', 'dentist', 'plumber')
    :param area_name: The geographic area (e.g., 'New York', 'London')
    :param timeout: Request timeout in seconds
    """
    if not query or not query.strip():
        raise ValueError("A business category (query) is required.")
    if not area_name or not area_name.strip():
        raise ValueError("A geographic area is required for OSM searches.")

    # Overpass QL Query
    # 1. Find the area by name
    # 2. Find nodes/ways/relations within that area with the specified amenity/shop/craft tag
    # 3. Filter out those that HAVE a 'website' tag
    
    # We try to map the 'query' to common OSM tags like amenity, shop, or craft
    # For a more robust system, a mapping dictionary could be used.
    overpass_query = f"""
    [out:json][timeout:25];
    area["name"="{area_name}"]->.searchArea;
    (
      node["amenity"="{query}"](area.searchArea);
      way["amenity"="{query}"](area.searchArea);
      node["shop"="{query}"](area.searchArea);
      way["shop"="{query}"](area.searchArea);
      node["craft"="{query}"](area.searchArea);
      way["craft"="{query}"](area.searchArea);
    );
    node(r);
    way(r);
    out center;
    """

    try:
        response = requests.post(OVERPASS_URL, data={"data": overpass_query}, timeout=timeout)
        response.raise_for_status()
        data = response.json()
    except (requests.exceptions.RequestException, ValueError) as e:
        print(f"Error querying Overpass API: {e}")
        return []

    results = []
    for element in data.get("elements", []):
        tags = element.get("tags", {})
        
        # Filter: Only include if there is NO website tag
        if "website" in tags:
            continue
            
        # Extract basic info
        name = tags.get("name", "Unknown Name")
        address = tags.get("addr:full") or \
                  f"{tags.get('addr:street', '')} {tags.get('addr:housenumber', '')}, {tags.get('addr:city', '')}".strip()
        phone = tags.get("phone") or tags.get("contact:phone", "")
        
        # Create a link to OSM for reference
        osm_id = element.get("id")
        osm_url = f"https://www.openstreetmap.org/{'way' if element.get('type') == 'way' else 'node'}/{osm_id}"

        results.append({
            "id": str(osm_id),
            "name": name,
            "address": address or "No address listed",
            "phone": phone,
            "maps_url": osm_url,
            "rating": "N/A", # OSM doesn't provide ratings
            "types": tags.get("amenity") or tags.get("shop") or tags.get("craft") or "business",
            "website": "",
        })

    return results


def save_business_report(businesses, output_dir=None):
    """Save business results as a timestamped CSV and return its path."""
    target_dir = Path(output_dir or Path(__file__).resolve().parent.parent / "reports")
    target_dir.mkdir(parents=True, exist_ok=True)
    output_path = target_dir / f"osm_businesses_without_websites_{datetime.now():%Y%m%d_%H%M%S}.csv"
    fields = ["id", "name", "address", "phone", "maps_url", "rating", "types", "website"]
    with output_path.open("w", newline="", encoding="utf-8") as report:
        writer = csv.DictWriter(report, fieldnames=fields)
        writer.writeheader()
        writer.writerows(businesses)
    return output_path


__all__ = ["save_business_report", "search_businesses_without_websites"]
